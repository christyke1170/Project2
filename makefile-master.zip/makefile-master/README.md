# EECS 281 Makefile

Include this makefile in your EECS 281 projects and many
of your troubles will go away...

**Using this Makefile is no substitute for learning make and
understanding Makefiles!**

Usage:
    make help

Make sure you search for **TODO** and update the Makefile
