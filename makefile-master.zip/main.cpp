#include <iostream>
#include <string>
#include <cmath>
#include "P2random.h"
#include <cstdlib>
#include <queue> 
#include <algorithm>
#include <iomanip>
#include <stdio.h>
#include <string.h>

using namespace std;

struct Tile {
	int col = 0;
	int row = 0;
	int rubble;
	bool tnt = false;
	bool visible = false;
	bool visited = false;
};
struct CompareRubble {
	bool operator()(const Tile& lhs, const Tile& rhs) const {
		return lhs.rubble > rhs.rubble;
	}
};

struct TileMap {
	priority_queue<Tile, vector<Tile>, CompareRubble> queue;
	priority_queue<Tile, vector<Tile>, CompareRubble> tntQueue;
	vector<vector<Tile>> grid;
	vector<int> median;
	string mapMode = "";
	int unsigned size = 0;
	int unsigned seed = 0;
	int unsigned maxRubble = 0;
	int unsigned tnt = 0;
	int unsigned currentRow = 0;
	int unsigned currentCol = 0;
	int totalTileCleared = 0;
	int totalRubbleCleared = 0;
	bool stats = false;
	bool medianMode = false;
	bool verbose = false;
	void readInMap();
	void readInPseudo();
	void travelTile();
	void tntExplosion();
	void calcTNT();
	bool notAtEdge();
	double returnMedian();
};
int main(int argc, char* argv[]) {
	ios_base::sync_with_stdio(false);
	cout << fixed << setprecision(2);
	TileMap journey;

	for (int i = 0; i < argc; ++i) {
		if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "help")) {
			cout << "help haha \n";
			exit(0);
		}
		else if (!strcmp(argv[i], "-v") || !strcmp(argv[i], "verbose")) {
			journey.verbose = true;
		}
		else if (!strcmp(argv[i], "-s") || !strcmp(argv[i], "stats")) {
			journey.stats = true;
		}
		else if (!strcmp(argv[i], "-m") || !strcmp(argv[i], "median")) {
			journey.medianMode = true;
		}
	}

	string dummy;
	cin >> journey.mapMode;
	cin >> dummy;
	cin >> journey.size;
	cin >> dummy;
	cin >> journey.currentRow;
	cin >> journey.currentCol;
	if ((journey.currentRow >= journey.size) || (journey.currentCol >= journey.size)) {
		cerr << "the start coordinate is not within the grid!" << endl;
		exit(1);
	}
	journey.grid.resize(journey.size);
	for (int unsigned i = 0; i < journey.size; ++i) {
		journey.grid[i].resize(journey.size);
	}
	if (journey.mapMode == "R") {
		cin >> dummy;
		cin >> journey.seed;
		cin >> dummy;
		cin >> journey.maxRubble;
		cin >> dummy;
		cin >> journey.tnt;
		journey.readInPseudo();
	}
	else if (journey.mapMode == "M") {
		journey.readInMap();
	}
	else {
		cerr << "not a valid input" << endl;
		exit(1);
	}

	journey.grid[journey.currentRow][journey.currentCol].visible = true;

	// START LOOP HERE ----------------------------------//

	while (journey.notAtEdge()) {
		if (journey.grid[journey.currentRow][journey.currentCol].rubble == -1) {
			//if tnt
			journey.tntExplosion();
		}
		else if (journey.tntQueue.size() > 0) {
			journey.calcTNT();
		}
		else {
			journey.travelTile();
		}
	}
	cout << "Cleared " << journey.totalTileCleared;
	cout << " tiles containing " << journey.totalRubbleCleared;
	cout << " rubble and escaped.\n";
	exit(0);
}

void TileMap::readInMap() {
	Tile currentTile;
	for (int unsigned i = 0; i < size; ++i) {
		for (int unsigned j = 0; j < size; ++j) {
			currentTile.row = i;
			currentTile.col = j;
			cin >> currentTile.rubble;
			if (currentTile.rubble == -1)
				currentTile.tnt = true;
			grid[i][j] = currentTile;
		}
	}
}

void TileMap::readInPseudo() {
	stringstream ss;
	P2random::PR_init(ss, size, seed, maxRubble, tnt);
	Tile currentTile;
	for (int unsigned i = 0; i < size; ++i) {
		for (int unsigned j = 0; j < size; ++j) {
			currentTile.row = i;
			currentTile.col = j;
			ss >> currentTile.rubble;
			if (currentTile.rubble == -1)
				currentTile.tnt = true;
			grid[i][j] = currentTile;
		}
	}
}

void TileMap::travelTile() {
	int rubble = grid[currentRow][currentCol].rubble;
	int wall = size - 1;
	int col = currentCol;
	int row = currentRow;
	totalRubbleCleared += rubble;
	median.push_back(rubble);
	if (verbose) {
		cout << "Cleared: " << rubble << " at [" << currentRow << "," << currentCol << "]\n";
	}
	grid[currentRow][currentCol].visited = true;
	grid[currentRow][currentCol].rubble = 0;

	if (row < wall) { //down
		if (grid[currentRow + 1][currentCol].visible == false) {
			grid[currentRow + 1][currentCol].visible = true;
			queue.push(grid[currentRow + 1][currentCol]);
		}
	}
	if (col < wall) {//right
		if (grid[currentRow][currentCol + 1].visible == false) {
			grid[currentRow][currentCol + 1].visible = true;
			queue.push(grid[currentRow][currentCol + 1]);
		}
	}
	if (currentRow >= 1) {//up
		if (grid[currentRow - 1][currentCol].visible == false) {
			grid[currentRow - 1][currentCol].visible = true;
			queue.push(grid[currentRow - 1][currentCol]);
		}
	}
	if (currentCol >= 1) {//left
		if (grid[currentRow][currentCol - 1].visible == false) {
			grid[currentRow][currentCol - 1].visible = true;
			queue.push(grid[currentRow][currentCol - 1]);
		}
	}

	if (medianMode) {
		cout << "Median difficulty of clearing rubble is: " << returnMedian() << "\n";
	}

	currentRow = queue.top().row;
	currentCol = queue.top().col;
	Tile temp = queue.top(); //check for ties
	queue.pop();
	if (queue.top().rubble == temp.rubble) {
		if (queue.top().col < temp.col) {
			queue.push(temp);
			currentRow = queue.top().row;
			currentCol = queue.top().col;
			queue.pop();
		}
		else if (queue.top().col == temp.col) {
			if (queue.top().row < temp.row) {
				queue.push(temp);
				currentRow = queue.top().row;
				currentCol = queue.top().col;
				queue.pop();
			}
		}
	}
	totalTileCleared++;
}

void TileMap::tntExplosion() {
	if (verbose) {
		cout << "TNT explosion at [" << currentRow << "," << currentCol << "]!\n";
	}
	int wall = size - 1;
	int col = currentCol;
	int row = currentRow;
	grid[currentRow][currentCol].visited = true;
	grid[currentRow][currentCol].rubble = 0;

	if (row < wall) { //down
		grid[currentRow + 1][currentCol].visible = true;
		if (grid[currentRow + 1][currentCol].rubble != 0) { //checking to make sure not 0
			tntQueue.push(grid[currentRow + 1][currentCol]);
		}
	}
	if (col < wall) {//right
		grid[currentRow][currentCol + 1].visible = true;
		if (grid[currentRow][currentCol + 1].rubble != 0) {
			tntQueue.push(grid[currentRow][currentCol + 1]);
		}
	}
	if (currentRow >= 1) {//up
		grid[currentRow - 1][currentCol].visible = true;
		if (grid[currentRow - 1][currentCol].rubble != 0) {
			tntQueue.push(grid[currentRow - 1][currentCol]);
		}
	}
	if (currentCol >= 1) {//left
		grid[currentRow][currentCol - 1].visible = true;
		if (grid[currentRow][currentCol - 1].rubble != 0) {
			tntQueue.push(grid[currentRow][currentCol - 1]);
		}
	}

	currentRow = tntQueue.top().row;
	currentCol = tntQueue.top().col;
	Tile temp = tntQueue.top(); //check for ties
	tntQueue.pop();
	if (tntQueue.top().rubble == temp.rubble) {
		if (tntQueue.top().col < temp.col) {
			tntQueue.push(temp);
			currentRow = tntQueue.top().row;
			currentCol = tntQueue.top().col;
			tntQueue.pop();
		}
		else if (tntQueue.top().col == temp.col) {
			if (tntQueue.top().row < temp.row) {
				tntQueue.push(temp);
				currentRow = tntQueue.top().row;
				currentCol = tntQueue.top().col;
				tntQueue.pop();
			}
		}
	}
}

void TileMap::calcTNT() {
	int rubbletemp = grid[currentRow][currentCol].rubble;
	totalRubbleCleared += rubbletemp;
	grid[currentRow][currentCol].rubble = 0;
	grid[currentRow][currentCol].visible = true;
	queue.push(grid[currentRow][currentCol]);
	totalTileCleared++;
	median.push_back(rubbletemp);
	if (verbose) {
		cout << "Cleared by TNT: " << rubbletemp << " at [" << currentRow << "," << currentCol << "]\n";
	}
	if (medianMode) {
		cout << "Median difficulty of clearing rubble is: " << returnMedian() << "\n";
	}

	while (!tntQueue.empty()) {
		Tile temp = tntQueue.top();
		Tile boom = temp;
		tntQueue.pop();
		if (tntQueue.top().rubble == temp.rubble) {
			if (tntQueue.top().col < temp.col) {
				tntQueue.push(temp);
				boom = tntQueue.top();
				tntQueue.pop();
			}
			else if (tntQueue.top().col == temp.col) {
				if (tntQueue.top().row < temp.row) {
					tntQueue.push(temp);
					boom = tntQueue.top();
					tntQueue.pop();
				}
			}
		}
		median.push_back(boom.rubble);
		if (verbose) {
			cout << "Cleared by TNT: " << boom.rubble << " at [" << boom.row << "," << boom.col << "]\n";
		}
		if (medianMode) {
			cout << "Median difficulty of clearing rubble is: " << returnMedian() << "\n";
		}

		totalRubbleCleared += grid[boom.row][boom.col].rubble;
		grid[boom.row][boom.col].rubble = 0;
		grid[boom.row][boom.col].visible = true;
		queue.push(grid[boom.row][boom.col]);
		totalTileCleared++; 
	}
	currentRow = queue.top().row;
	currentCol = queue.top().col;
	Tile temp = queue.top(); //check for ties
	queue.pop();
	if (queue.top().rubble == temp.rubble) {
		if (queue.top().col < temp.col) {
			queue.push(temp);
			currentRow = queue.top().row;
			currentCol = queue.top().col;
			queue.pop();
		}
		else if (queue.top().col == temp.col) {
			if (queue.top().row < temp.row) {
				queue.push(temp);
				currentRow = queue.top().row;
				currentCol = queue.top().col;
				queue.pop();
			}
		}
	}
}
bool TileMap::notAtEdge() {
	if (tntQueue.empty()) {
		if (currentCol == 0) {
			return false;
		}
		if (currentRow == 0) {
			return false;
		}
		if (currentCol == size - 1) {
			return false;
		}
		if (currentRow == size - 1) {
			return false;
		}
	}
	return true;
}

double TileMap::returnMedian() {
	double medianReturn;
	size_t medianSize = median.size();
	sort(median.begin(), median.begin() + medianSize);
	cout << "median called and current contains: ";
	for (int i = 0; i < (int)medianSize; ++i) {
		cout << median[i] << endl;
	}
	if ((int) medianSize % 2 == 0) { //if even
		medianReturn = (median[medianSize / 2 - 1] + median[medianSize / 2]) / 2;
	}
	else {
		medianReturn = median[medianSize / 2];
	}
	return medianReturn;
}